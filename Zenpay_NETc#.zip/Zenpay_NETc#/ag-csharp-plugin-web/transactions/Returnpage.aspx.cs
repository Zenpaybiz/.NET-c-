﻿using Encryption.AES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MerchantSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Params.Count > 0)
        {

            string salt = "";
            string order_id = (!String.IsNullOrEmpty(Request.Params["order_id"])) ? Request.Params["order_id"] : string.Empty;
            string amount = (!String.IsNullOrEmpty(Request.Params["amount"])) ? Request.Params["amount"] : string.Empty;
            string currency = (!String.IsNullOrEmpty(Request.Params["currency"])) ? Request.Params["currency"] : string.Empty;
            string description = (!String.IsNullOrEmpty(Request.Params["description"])) ? Request.Params["description"] : string.Empty;
            string name = (!String.IsNullOrEmpty(Request.Params["name"])) ? Request.Params["name"] : string.Empty;
            string email = (!String.IsNullOrEmpty(Request.Params["email"])) ? Request.Params["email"] : string.Empty;
            string phone = (!String.IsNullOrEmpty(Request.Params["phone"])) ? Request.Params["phone"] : string.Empty;
            string address_line_1 = (!String.IsNullOrEmpty(Request.Params["address_line_1"])) ? Request.Params["address_line_1"] : string.Empty;
            string address_line_2 = (!String.IsNullOrEmpty(Request.Params["address_line_2"])) ? Request.Params["address_line_2"] : string.Empty;
            string city = (!String.IsNullOrEmpty(Request.Params["city"])) ? Request.Params["city"] : string.Empty;
            string state = (!String.IsNullOrEmpty(Request.Params["state"])) ? Request.Params["state"] : string.Empty;
            string country = (!String.IsNullOrEmpty(Request.Params["country"])) ? Request.Params["country"] : string.Empty;
            string zip_code = (!String.IsNullOrEmpty(Request.Params["zip_code"])) ? Request.Params["zip_code"] : string.Empty;
            string udf1 = (!String.IsNullOrEmpty(Request.Params["udf1"])) ? Request.Params["udf1"] : string.Empty;
            string udf2 = (!String.IsNullOrEmpty(Request.Params["udf2"])) ? Request.Params["udf2"] : string.Empty;
            string udf3 = (!String.IsNullOrEmpty(Request.Params["udf3"])) ? Request.Params["udf3"] : string.Empty;
            string udf4 = (!String.IsNullOrEmpty(Request.Params["udf4"])) ? Request.Params["udf4"] : string.Empty;
            string udf5 = (!String.IsNullOrEmpty(Request.Params["udf5"])) ? Request.Params["udf5"] : string.Empty;
            string transaction_id = (!String.IsNullOrEmpty(Request.Params["transaction_id"])) ? Request.Params["transaction_id"] : string.Empty;
            string payment_mode = (!String.IsNullOrEmpty(Request.Params["payment_mode"])) ? Request.Params["payment_mode"] : string.Empty;
            string payment_channel = (!String.IsNullOrEmpty(Request.Params["payment_channel"])) ? Request.Params["payment_channel"] : string.Empty;
             string payment_datetime = (!String.IsNullOrEmpty(Request.Params["payment_datetime"])) ? Request.Params["payment_datetime"] : string.Empty;
            string response_code = (!String.IsNullOrEmpty(Request.Params["response_code"])) ? Request.Params["response_code"] : string.Empty;
            string response_message = (!String.IsNullOrEmpty(Request.Params["response_message"])) ? Request.Params["response_message"] : string.Empty;
            string error_desc = (!String.IsNullOrEmpty(Request.Params["error_desc"])) ? Request.Params["error_desc"] : string.Empty;
            string cardmasked = (!String.IsNullOrEmpty(Request.Params["cardmasked"])) ? Request.Params["cardmasked"] : string.Empty;
            string hash = (!String.IsNullOrEmpty(Request.Params["hash"])) ? Request.Params["hash"] : string.Empty;



            var response = new SortedDictionary<string, string>();
            response.Add("order_id", order_id);
            response.Add("amount", amount);
            response.Add("currency", currency);
            response.Add("description", description);
            response.Add("name", name);
            response.Add("email", email);
            response.Add("phone", phone);
            response.Add("address_line_1", address_line_1);
            response.Add("address_line_2", address_line_2);
            response.Add("city", city);
            response.Add("state", state);
            response.Add("country", country);
            response.Add("zip_code", zip_code);
            response.Add("udf1", udf1);
            response.Add("udf2", udf2);
            response.Add("udf3", udf3);
            response.Add("udf4", udf4);
            response.Add("udf5", udf5);
            response.Add("transaction_id", transaction_id);
            response.Add("payment_mode", payment_mode);
            response.Add("payment_channel", payment_channel);
            response.Add("payment_datetime", payment_datetime);
            response.Add("response_code", response_code);
            response.Add("response_message", response_message);
            response.Add("error_desc", error_desc);
            response.Add("cardmasked", cardmasked);
            


            string data = salt;
            string createhash = "";
            MyCryptoClass aes = new MyCryptoClass();

            foreach (var item in response)
            {
                if (item.Value.Length > 0)
                {
                    data += "|" + item.Value.Trim();
                    createhash = aes.Generatehash512(data);
                }
            }

            string message = "Hash Mismatched";

            if (hash.Equals(createhash))
            {
                 message = "Hash Matched";
            }

            string status = "failed";

            if (response_code.Equals("0"))
            {
                status = "successful";
            }


            lblAgRef.Text = transaction_id;
            lblAmount.Text = amount;
            lblOrderNumber.Text = order_id;
            lblResponseMessage.Text = response_message;
            lblTransactionDate.Text = payment_datetime;
            lblTransactionStatus.Text = status;
            lblhash.Text = message;


        }
    }
}